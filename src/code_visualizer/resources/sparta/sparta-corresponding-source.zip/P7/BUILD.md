# Reproduce the P7 serial Windows build

This is SPARTA upstream e071055fca6ccd250d4b894dadb7ff64d6e6fcac plus the
documented P7 adapter and Windows build changes. Original and changed native
files are supplied under SPARTA's GPLv2 terms; see LICENSE. Added adapter code
observes state/emission/moments and updates existing native reservoirs. It adds
no particle sampling, movement or collision law. The source manifest identifies
every change and the compiler, wrappers, commands and SOURCE_DATE_EPOCH.

The original harness build_sparta_probe.py records the exact source/build paths
used in the receipt. To reproduce elsewhere, use this source directory as its
SOURCE location and a separate build directory. Install cmake 4.4.3, ninja
1.13.2 and ziglang 0.16.0 into a Python environment; configure the serial shared
Release target with MPI stubs, exceptions enabled and no optional accelerator.
The manifest contains the generated Zig C/C++ wrappers and compiler arguments.
The Windows target is x86_64-windows-gnu. Build with the recorded source epoch
and bounded parallelism. Copy the resulting src/libsparta_p7serial.dll.

The workbench intentionally refuses a different native binary for exact
continuation; a rebuild with a different hash needs its own native method
qualification and must not replace an accepted experiment's binary silently.
