"""Disposable B0 native feasibility build, invoked only by run_checks.py."""

import argparse
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import shutil
import sys
from hashlib import sha256

import cmake
import ninja
import ziglang

parser = argparse.ArgumentParser()
parser.add_argument("stage", choices=("configure", "build"))
args = parser.parse_args()
app = Path(__file__).resolve().parents[2] / "code visualizer"
root = app / "artifacts/p7-b0"
source = root / "sparta-source"
build = root / "build-zig-01"
assert source.is_dir() and build.resolve().is_relative_to(root.resolve())
build.mkdir(exist_ok=True)
zig = Path(ziglang.__file__).parent / "zig.exe"
compiler = Path(cmake.CMAKE_BIN_DIR) / "cmake.exe"
ninja_binary = Path(ninja.BIN_DIR) / "ninja.exe"
for path in (zig, compiler, ninja_binary):
    assert path.is_file(), path
environment = dict(os.environ)
environment["CMAKE_BUILD_PARALLEL_LEVEL"] = "2"
environment["ZIG_GLOBAL_CACHE_DIR"] = str(root / "zig-cache")
environment["SOURCE_DATE_EPOCH"] = subprocess.check_output(
    ["git", "show", "-s", "--format=%ct", "HEAD"], cwd=source, text=True
).strip()
git_exe = Path(shutil.which("git")).resolve()
git_shell = git_exe.parent.parent / "usr/bin"
if (git_shell / "sh.exe").is_file():
    environment["PATH"] = str(git_shell) + os.pathsep + environment["PATH"]
driver = build / "compiler_driver.py"
driver.write_text(
    "import subprocess, sys\n"
    + "zig = " + repr(str(zig)) + "\n"
    + "kind, *args = sys.argv[1:]\n"
    + "extra = ['-x', 'c++'] if kind == 'c++' and '-c' in args else []\n"
    + "if kind in ('cc', 'c++'): extra += ['-target', 'x86_64-windows-gnu', '-Wno-error=date-time']\n"
    + "sys.exit(subprocess.call([zig, kind, *extra, *args]))\n", encoding="utf-8",
)
wrappers = {}
for name, operation in (("cc", "cc"), ("cxx", "c++"), ("ar", "ar"), ("ranlib", "ranlib")):
    wrapper = build / ("zig-" + name + ".cmd")
    wrapper.write_text(f'@"{sys.executable}" "{driver}" {operation} %*\n', encoding="utf-8")
    wrappers[name] = wrapper.as_posix()
if args.stage == "configure":
    identity = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip()
    print(json.dumps({"upstream_commit": identity, "build_directory": str(build),
        "packages": {name: importlib.metadata.version(name) for name in ("ziglang", "cmake", "ninja")},
        "compiler": str(zig), "parallel_build_jobs": 2}, indent=2), flush=True)
    command = [str(compiler), "-S", str(source / "cmake"), "-B", str(build), "-G", "Ninja",
        "-DCMAKE_MAKE_PROGRAM=" + str(ninja_binary), "-DCMAKE_SYSTEM_NAME=Windows",
        "-DCMAKE_C_COMPILER=" + wrappers["cc"], "-DCMAKE_CXX_COMPILER=" + wrappers["cxx"],
        "-DCMAKE_AR=" + wrappers["ar"], "-DCMAKE_RANLIB=" + wrappers["ranlib"],
        "-DCMAKE_BUILD_TYPE=Release", "-DBUILD_SHARED_LIBS=ON", "-DBUILD_MPI=OFF",
        "-DPKG_MPI_STUBS=ON", "-DSPARTA_MACHINE=p7serial",
        "-DSPARTA_DEFAULT_CXX_COMPILE_FLAGS=-DSPARTA_EXCEPTIONS",
        "-DSPARTA_ENABLE_TESTING=OFF"]
else:
    command = [str(compiler), "--build", str(build), "--parallel", "2"]
files = subprocess.check_output(["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=source).decode("utf-8").split("\0")
new_files = subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "-z"], cwd=source).decode("utf-8").split("\0")
manifest = {
    "upstream_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip(),
    "tracked_source": {name: sha256((source / name).read_bytes()).hexdigest() for name in files if name},
    "diff": subprocess.check_output(["git", "diff", "--no-ext-diff", "HEAD"], cwd=source, text=True),
    "new_source": {name: (source / name).read_text(encoding="utf-8") for name in new_files if name},
    "wrappers": {p.name: p.read_text(encoding="utf-8") for p in build.glob("zig-*.cmd")},
    "driver": driver.read_text(encoding="utf-8"),
    "compiler_sha256": sha256(zig.read_bytes()).hexdigest(),
    "source_date_epoch": environment["SOURCE_DATE_EPOCH"],
}
data = json.dumps(manifest, sort_keys=True, indent=2).encode("utf-8")
source_record = Path(__file__).parent / ("sparta-native-source-" + sha256(data).hexdigest() + ".json")
if source_record.exists():
    assert source_record.read_bytes() == data
else:
    source_record.write_bytes(data)
print("Native source/build input: " + source_record.name, flush=True)
print(json.dumps(command), flush=True)
result = subprocess.call(command, env=environment)
if result == 0 and args.stage == "build":
    library = build / "src/libsparta_p7serial.dll"
    binary_digest = sha256(library.read_bytes()).hexdigest()
    retained = root / "binaries" / binary_digest
    retained.mkdir(parents=True, exist_ok=True)
    target = retained / library.name
    if target.exists():
        assert sha256(target.read_bytes()).hexdigest() == binary_digest
    else:
        shutil.copyfile(library, target)
    (retained / "source-manifest.json").write_bytes(data)
    print(json.dumps({"binary_sha256": binary_digest, "retained": str(target)}), flush=True)
sys.exit(result)
